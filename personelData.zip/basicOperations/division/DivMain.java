package op.basicOperations.division;

public class DivMain {
    public static void main(String[] args) {


    Division division = new Division();
    division.number1=9;
    division.number2=3;
        System.out.println(division.divide());
}
}

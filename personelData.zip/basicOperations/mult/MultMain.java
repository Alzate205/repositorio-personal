package op.basicOperations.mult;

public class MultMain {
    public static void main(String[] args) {
        Multiplication multiplication = new Multiplication();
        multiplication.number1=2;
        multiplication.number2=182;
        System.out.println("the result of the multiplication is: "+ multiplication.mult());
    }
}

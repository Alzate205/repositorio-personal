package op.basicOperations.mult;

public class Multiplication {
    public int number1;
    public int number2;
    public int mult(){
        return number1*number2;
    }
}

package op.basicOperations.sub;

public class SubMain {
    public static void main(String[] args) {
        Substraction substraction = new Substraction();
        substraction.number1=123123;
        substraction.number2=231123;
        System.out.println("the result of the subtraction is: "+ substraction.sub());
    }
}

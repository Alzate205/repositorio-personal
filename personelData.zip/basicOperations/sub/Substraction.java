package op.basicOperations.sub;

public class Substraction {
    public int number1;
    public int number2;
    public int sub(){
        return number1-number2;
    }
}

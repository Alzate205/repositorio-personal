package op.basicOperations.sum;

public class Addition {
    public int number1;
    public int number2;

    public int add(){
        return number1+number2;
    }
}

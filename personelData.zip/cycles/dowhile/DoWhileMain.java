package op.cycles.dowhile;

public class DoWhileMain {
    public static void main(String[] args) {
        DoWhile cycle = new DoWhile();
        cycle.start= 2;
        cycle.end = 10;
        cycle.showDoWhile();
    }
}

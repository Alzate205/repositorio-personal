package op.cycles.forCycle;

public class ForCode {
    public int start;
    public int finish;
    public void showCycle(){
        for (int i = start; i <= finish; i++) {
            System.out.println(i);
}}}

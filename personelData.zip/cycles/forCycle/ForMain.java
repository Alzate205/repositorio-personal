package op.cycles.forCycle;

public class ForMain {
    public static void main(String[] args) {
        ForCode code = new ForCode();
        code.start=1;
        code.finish=10;
        code.showCycle();
    }
}

package op.cycles.whileCycle;

public class WhileCycle {
    public int x;
    public void cycle(){
        while (x<=10){
            System.out.println(x);
            x++;
    }
}}

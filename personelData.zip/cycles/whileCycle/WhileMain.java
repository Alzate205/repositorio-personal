package op.cycles.whileCycle;

public class WhileMain {
    public static void main(String[] args) {
        WhileCycle cycle= new WhileCycle();
        cycle.x=1;
        cycle.cycle();
    }
}

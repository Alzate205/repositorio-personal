package op.desicions.ternary;

public class TernaryCode {
}

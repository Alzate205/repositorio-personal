package op.desicions.ternary;

public class ternaryMain {
}

package op.personelData;

public class PersonMain {
    public static void main(String[] args) {
        Person_data person = new Person_data();
        person.name= "popo";
        person.favorite_number=9293;
        person.age=69;
        System.out.println(person.prank());
    }
    }


package op.personelData;

public class Person_data {
  public String name;
    public int age;
    public int favorite_number;
    public String prank(){
        return "hola señor "+age+" su edad es "+name+" y su numero favorito es "+favorite_number;
    }
}

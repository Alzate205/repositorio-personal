package switch1;

public class Switch1 {

    public int option;

    public String showOption (){
        switch (option){
            case 1:{
                return "Your reward is a hat..";
            }
            case 2:{
                return "Your reward is a bombom";
            }
            default:{
                return "incorrect option..";
            }
        }
    }
}
